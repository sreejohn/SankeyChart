
const nodes = [{
  "name": "Salary",
  "node": 0
}, {
  "name": "Bills",
  "node": 1
}, {
  "name": "Electric bill",
  "node": 2
}, {
  "name": "Mobile bill",
  "node": 3
}, {
  "name": "Others",
  "node": 4
}

]

let links = [{
  "source": 0,
  "target": 1,
  "value": 3000
}, {
  "source": 1,
  "target": 2,
  "value": 1000
}, {
  "source": 1,
  "target": 3,
  "value": 2000
}, {
  "source": 0,
  "target": 4,
  "value": 2000
}]




function loadData() {
  let obj = {};
  obj.nodes = nodes;
  obj.links = links;
  return obj;

}




export { loadData }
