import React from 'react';
import Modal from 'react-modal';
import { loadData } from './utils';
import SankeyChart from './SankeyChart';
import bootstrap from 'bootstrap/dist/css/bootstrap.css';
import style from './sankey.css';


class Charts extends React.Component {
    constructor() {
        super()

        this.state = {
            nodes: [],
            links: [],
            modalIsOpen: false
        };

        this.loadData = loadData.bind(this);
        this.updateNode = this.updateNode.bind(this);
        this.addLink = this.addLink.bind(this);
        this.updateLink = this.updateLink.bind(this);
        this.openModal = this.openModal.bind(this);
        this.closeModal = this.closeModal.bind(this);
        this.closeAndSaveModal = this.closeAndSaveModal.bind(this);
        this.handleInputChange = this.handleInputChange.bind(this);
    }


    componentDidMount() {
        /*****Fetching data from server*********/
        const data = this.loadData();
        this.setState({
            nodes: data.nodes,
            links: data.links
        });
    }








    updateNode(name, idx) {
        var nodes = this.state.nodes;
        nodes[idx]['name'] = name;

        this.setState({ nodes });
    }


    addLink(source, target, value) {
        if (this.state.nodes.length > 1 && !isNaN(value) && !isNaN(source) && !isNaN(target)) {

            var links = this.state.links;
            var idx = links.length;

            links[idx] = { source, target, value };
            this.setState({ links });
        }
    }


    updateLink(source, target, value) {
        var links = this.state.links.map((link) => {
            if (link.source === source && link.target === target) {
                link.value = value;
            }
            return link;
        });

        this.setState({ links });
    }


    openModal(e) {
        if (e.node !== undefined) {
            var modalContent = 'node';
            var modalContentNodeId = e.node;
            var modalContentNodeName = e.name;
        } else if (e.value !== undefined) {
            var modalContent = 'link';
            var modalContentLinkValue = e.value;
            var modalContentLinkSource = e.source.node;
            var modalContentLinkTarget = e.target.node;
        }

        this.setState({
            modalIsOpen: true,
            modalContent,
            modalContentNodeId,
            modalContentNodeName,
            modalContentLinkValue,
            modalContentLinkSource,
            modalContentLinkTarget
        });
    }


    closeModal() {
        this.setState({ modalIsOpen: false });
    }


    closeAndSaveModal() {
        if (this.state.modalContent === 'link') {
            this.updateLink(this.state.modalContentLinkSource, this.state.modalContentLinkTarget, this.state.modalContentLinkValue);
        } else if (this.state.modalContent === 'node') {
            this.updateNode(this.state.modalContentNodeName, this.state.modalContentNodeId);
        }
        this.setState({ modalIsOpen: false });
    }


    handleInputChange(key) {
        if (this.state.modalContent === 'link') {
            this.setState({ modalContentLinkValue: key.target.value });
        } else if (this.state.modalContent === 'node') {
            this.setState({ modalContentNodeName: key.target.value });
        }
    }


    render() {
        if (this.state.modalContent === 'link') {
            var modalValue = this.state.modalContentLinkValue;
            var header = 'Update Link Weight';
        } else if (this.state.modalContent === 'node') {
            var modalValue = this.state.modalContentNodeName;
            var header = 'Update Node Name';
        }

        var modalStyle = {
            content: {
                top: '275px',
                left: '37%',
                right: 'auto',
                bottom: 'auto',
                border: '0px solid #333',
                width: '300px',
            },
            overlay: {
                backgroundColor: 'rgba(0, 0, 0 , 0.35)'
            }
        };

        return (
            <div>
                <div className="header">
                    <a href="#" className="logo">CompanyLogo</a>
                    <div className="header-right">
                        Welcome user
                 </div>
                </div>
                <center>
                    <h2>Sankey Chart</h2>
                    <div style={{ border: "1px solid gray", margin: "5%" }}>
                        <SankeyChart nodes={this.state.nodes} links={this.state.links} openModal={this.openModal} />
                    </div></center>
                <Modal
                    closeTimeoutMS={150}
                    isOpen={this.state.modalIsOpen}
                    onRequestClose={this.handleModalCloseRequest}
                    style={modalStyle}>
                    <button className="close" onClick={this.closeModal}>
                        <span aria-hidden="true">&times;</span>
                    </button>
                    <h4>{header}</h4>
                    <hr />
                    <input
                        className="form-control"
                        defaultValue={modalValue}
                        onChange={this.handleInputChange}
                    />
                    <hr />
                    <div className="row">
                        <div className="col-xs-12">
                            <button className="btn btn-primary btn-block" onClick={this.closeAndSaveModal}>Apply Changes</button>
                        </div>
                    </div>
                </Modal>
            </div>
        );
    }
};


export default Charts;
