import './App.css';
import Charts from './Charts';
function App() {
  return (
    <div className="App">
    <Charts></Charts>
    </div>
  );
}

export default App;
